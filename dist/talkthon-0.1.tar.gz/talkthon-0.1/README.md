# talk-thon
Get random sentences!
